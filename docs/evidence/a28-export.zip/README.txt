纪念备份

content.json 使用站点静态内容结构。
photos/ 中保存本次可见照片。
替换站点时，把 content.json 放到 public/content.json。
把 photos/ 中对应照片按 content.json 的 src 文件名放入 public/memories/。
云端存储路径可能保留在 photos/ 的子目录中，复制时以 content.json 的文件名为准。

导出日期：2026-11-13T18:59:12.161Z